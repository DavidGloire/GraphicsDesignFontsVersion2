Quilt Patches (c) Brittney Murphy 2022
https://www.brittneymurphydesign.com
info@brittneymurphydesign.com

By installing or using this font you agree to the following:

You may NOT redistribute this font without written permission.

This font is free for personal use ONLY.

For commercial use, please purchase a license:
https://www.brittneymurphydesign.com/downloads/quilt-patches-font/

For more information about licensing, visit:
https://www.brittneymurphydesign.com/fonts/licensing-information/
